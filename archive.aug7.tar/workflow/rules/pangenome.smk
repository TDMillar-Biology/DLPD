# pangenome.smk

# Specify your reference genome name here (must match the name in the SAMPLES list)
PANGENOME_REF = "ISO1" 

rule generate_cactus_seqfile:
    """
    Cactus requires a seqfile with the format:
    sample_name    /path/to/fasta
    """
    input:
        # Assuming SAMPLES is defined in your main Snakefile
        fastas = expand("results/{sample}/scaffold/{sample}.scaffolded.fasta", sample=SAMPLES)
    output:
        seqfile = "results/pangenome/seqfile.txt"
    run:
        with open(output.seqfile, "w") as out:
            for sample, fasta in zip(SAMPLES, input.fastas):
                # Ensure paths are resolved properly if cactus runs in a specific jobstore dir
                out.write(f"{sample}\t{fasta}\n")

rule build_pangenome_graph:
    """
    Constructs the pangenome graph using minigraph-cactus.
    Resources are specified to be caught by the Slurm profile.
    """
    input:
        seqfile = rules.generate_cactus_seqfile.output.seqfile
    output:
        outdir = directory("results/pangenome/cactus_out"),
        # Explicitly tracking the GFA output for downstream integration
        gfa = "results/pangenome/cactus_out/pangenome.gfa"
    log:
        "logs/pangenome/cactus_pangenome.log"
    threads: 32
    resources:
        mem_mb = 128000,
        time = "48:00:00",
        slurm_partition = "compute" # Adjust to match your specific cluster partition
    shell:
        """
        # Clean up any failed jobstore from previous runs
        rm -rf ./jobstore_pangenome

        # Run cactus-pangenome restricting Toil cores to the Snakemake Slurm allocation
        cactus-pangenome \\
            ./jobstore_pangenome \\
            {input.seqfile} \\
            --outDir {output.outdir} \\
            --outName pangenome \\
            --reference {PANGENOME_REF} \\
            --maxCores {threads} \\
            > {log} 2>&1
        """