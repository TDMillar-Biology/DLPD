rule plot_contiguity:
    input:
        assemblies = expand("results/{strain}/curated_assembly/{strain}.curated.fasta", strain=STRAINS),
        # This properly evaluates to all the 'full' paths from your config references
        refs = for_contiguity_plot
    output:
        plot = "results/aggregate/plots/contiguity.png"
    resources:
        mem_mb=1600,
        runtime=60,
        ntasks=1
    log:
        "logs/contiguity_plot/contiguity.log"
    container:
        "containers/python.sif"
    params:
        results_dir = "results",
        pattern = "curated_assembly/*.curated.fasta"
    shell:
        """
        mkdir -p $(dirname {output.plot})
         
        python3 workflow/scripts/plot_contiguity.py \
            --results {params.results_dir} \
            --reference-fastas {input.refs} \
            --pattern "{params.pattern}" \
            --max-contigs 20 \
            --output {output.plot} > {log} 2>&1
        """

rule aggregate_metrics:
    input:
        seqkit=expand("results/{strain}/qc/{strain}.seqkit.stats.tsv", strain=STRAINS),
        qv=expand("results/{strain}/qc/{strain}_qc.tsv", strain=STRAINS)
    output:
        "results/aggregate/tables/assembly_metrics.tsv"
    resources:
        mem_mb=1600,
        runtime=60,
        ntasks=1
    log:
        "logs/aggregate/aggregate.log"
    container:
        "containers/python.sif"
    shell:
        """
        mkdir -p logs/aggregate results/aggregate/tables

        python3 workflow/scripts/aggregate_metrics.py \
            --results results \
            --output {output} \
            > {log} 2>&1
        """
